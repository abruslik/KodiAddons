# -*- coding: utf-8 -*-

SITE_DOMAIN = 'filmix.me'
SITE_URL = 'https://'+SITE_DOMAIN
PLAYER_API_URL = SITE_URL + '/api/movies/player_data'
SEARCH_API_URL = SITE_URL + '/engine/ajax/sphinx_search.php'
SEARCH_REF_URL = SITE_URL + '/search/'